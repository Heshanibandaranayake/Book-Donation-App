package com.bookdrivebackend;

import com.bookdrivebackend.entities.User;
import com.bookdrivebackend.entities.UserRepository;
import com.bookdrivebackend.enums.UserTypes;
import com.bookdrivebackend.model.Donor;
import com.bookdrivebackend.repository.DonorRepository;
import groovy.util.logging.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Component
@Slf4j
public class DataInitializer implements CommandLineRunner {

    @Autowired
    UserRepository userRepository;

    @Autowired
    DonorRepository donorRepository;


    @Autowired
    PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        User user = userRepository.save(
                new User(Long.valueOf(1), "admin", passwordEncoder.encode("admin"), Arrays.asList( "ROLE_USER", "ROLE_ADMIN"), "Admin", UserTypes.ADMIN)
        );
        donorRepository.save(new Donor("Admin", user.getUsername(), "", user));
    }

}
