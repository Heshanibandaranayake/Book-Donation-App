package com.bookdrivebackend.enums;

public enum UserTypes {
    DRIVER, ADMIN, DONOR, CLUB
}
