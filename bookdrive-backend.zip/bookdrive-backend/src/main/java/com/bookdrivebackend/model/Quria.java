package com.bookdrivebackend.model;

import com.bookdrivebackend.entities.User;

import javax.persistence.*;

@Entity
@Table(name="quria_details")
public class Quria {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)

    private long Id;
    private String driverName;
    private String vehicleNumber;
    private String phoneNo;

    @OneToOne
    private User user;

    public Quria() {
    }

    public Quria(String driverName, String userName, String vehicleNumber, String phoneNo, User user) {
        this.driverName = driverName;
        this.vehicleNumber = vehicleNumber;
        this.phoneNo = phoneNo;
        this.user = user;
    }

    public long getId() {
        return Id;
    }

    public void setId(long id) {
        Id = id;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
