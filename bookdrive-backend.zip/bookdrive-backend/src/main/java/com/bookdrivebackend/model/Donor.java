package com.bookdrivebackend.model;

import com.bookdrivebackend.entities.User;

import javax.persistence.*;

@Entity
@Table(name="donors")
public class Donor {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long Id;

    private String donorName;
    private String phoneNo;

    @OneToOne
    private User user;

    public Donor() {
    }

    public Donor(String donorName, String userName, String phoneNo, User user) {
        this.donorName = donorName;
        this.phoneNo = phoneNo;
        this.user = user;
    }




    public long getId() {
        return Id;
    }

    public void setId(long id) {
        Id = id;
    }

    public String getDonorName() {
        return donorName;
    }

    public void setDonorName(String donorName) {
        this.donorName = donorName;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
