package com.bookdrivebackend.model;

import javax.persistence.*;

@Entity
@Table(name="posts_donor")
public class DonorPost {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long ID;
    private String numberOfBooks;
    private String bookCategory;

    @ManyToOne
    @JoinColumn(name = "donor_id")
    private Donor donor;

    @ManyToOne
    @JoinColumn(name = "accepted_club_id")
    private Club acceptedClub;

    public long getID() {
        return ID;
    }

    public void setID(long ID) {
        this.ID = ID;
    }

    public String getNumberOfBooks() {
        return numberOfBooks;
    }

    public void setNumberOfBooks(String numberOfBooks) {
        this.numberOfBooks = numberOfBooks;
    }

    public String getBookCategory() {
        return bookCategory;
    }

    public void setBookCategory(String bookCategory) {
        this.bookCategory = bookCategory;
    }

    public Donor getDonor() {
        return donor;
    }

    public void setDonor(Donor donor) {
        this.donor = donor;
    }

    public Club getAcceptedClub() {
        return acceptedClub;
    }

    public void setAcceptedClub(Club acceptedClub) {
        this.acceptedClub = acceptedClub;
    }
}
