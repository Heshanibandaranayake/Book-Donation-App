package com.bookdrivebackend.model;
import javax.persistence.*;

@Entity
@Table(name="post_society")

public class SocietyPost {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)

    private Long Id;
    private String bookCategory;
    private String closingDate;

    @ManyToOne
    @JoinColumn(name = "club_id")
    private Club club;


    public String getClosingDate() {
        return closingDate;
    }

    public void setClosingDate(String closingDate) {
        this.closingDate = closingDate;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getBookCategory() {
        return bookCategory;
    }

    public void setBookCategory(String bookCategory) {
        this.bookCategory = bookCategory;
    }

    public Club getClub() {
        return club;
    }

    public void setClub(Club club) {
        this.club = club;
    }
}
