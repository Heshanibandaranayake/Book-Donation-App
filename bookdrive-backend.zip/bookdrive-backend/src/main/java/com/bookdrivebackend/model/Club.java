package com.bookdrivebackend.model;

import com.bookdrivebackend.entities.User;

import javax.persistence.*;

@Entity
@Table(name="club_details")
public class Club {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long Id;
    private String clubName;
    private String phoneNo;

    @OneToOne
    private User user;

    public Club() {
    }

    public Club(String clubName, String userName, String phoneNo, User user) {
        this.clubName = clubName;
        this.phoneNo = phoneNo;
        this.user = user;
    }

    public long getId() {
        return Id;
    }

    public void setId(long id) {
        Id = id;
    }

    public String getClubName() {
        return clubName;
    }

    public void setClubName(String clubName) {
        this.clubName = clubName;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
