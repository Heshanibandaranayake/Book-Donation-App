package com.bookdrivebackend.repository;

import com.bookdrivebackend.model.SocietyPost;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PostClubRepository extends JpaRepository<SocietyPost, Long> {

}
