package com.bookdrivebackend.repository;

import com.bookdrivebackend.entities.User;
import com.bookdrivebackend.model.Donor;
import org.springframework.data.jpa.repository.JpaRepository;


public interface DonorRepository extends JpaRepository<Donor, Long> {
    Donor findByUser(User user);
}
