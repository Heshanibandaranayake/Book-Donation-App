package com.bookdrivebackend.repository;

import com.bookdrivebackend.entities.User;
import com.bookdrivebackend.model.Club;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClubRepository extends JpaRepository<Club,Long> {
    Club findByUser(User user);
}
