package com.bookdrivebackend.repository;

import com.bookdrivebackend.entities.User;
import com.bookdrivebackend.model.Quria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QuriaRepository extends JpaRepository<Quria,Long> {
    Quria findByUser(User user);
}
