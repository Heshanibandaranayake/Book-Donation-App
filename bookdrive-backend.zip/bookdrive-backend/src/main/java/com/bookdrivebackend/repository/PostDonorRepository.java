package com.bookdrivebackend.repository;

import com.bookdrivebackend.model.Club;
import com.bookdrivebackend.model.Donor;
import com.bookdrivebackend.model.DonorPost;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;


public interface PostDonorRepository extends JpaRepository<DonorPost, Long> {
    List<DonorPost> findByDonor(Donor donor);
    List<DonorPost> findByAcceptedClub(Club club);

    @Query("select p from DonorPost p where p.acceptedClub != null")
    List<DonorPost> findAcceptedPosts();
}
