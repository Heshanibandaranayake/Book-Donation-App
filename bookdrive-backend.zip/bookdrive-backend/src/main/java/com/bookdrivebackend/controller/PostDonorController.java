package com.bookdrivebackend.controller;

import com.bookdrivebackend.entities.User;
import com.bookdrivebackend.entities.UserRepository;
import com.bookdrivebackend.exception.ResourceNotFoundException;
import com.bookdrivebackend.model.Donor;
import com.bookdrivebackend.model.DonorPost;
import com.bookdrivebackend.repository.DonorRepository;
import com.bookdrivebackend.repository.PostDonorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
public class PostDonorController {
    @Autowired
    PostDonorRepository postDonorRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    DonorRepository donorRepository;


    @PostMapping("/auth/createDonorPost")
    public DonorPost createNewDonorPost(@RequestBody @Valid DonorPost donorPost, @AuthenticationPrincipal UserDetails userDetails){
        User user = userRepository.findByUsername(userDetails.getUsername()).orElseThrow(() -> new ResourceNotFoundException("User", "Username", userDetails.getUsername()));
        Donor donor = donorRepository.findByUser(user);
        donorPost.setDonor(donor);
        return postDonorRepository.save(donorPost);
    }
    @GetMapping("/auth/getDonorPost")
    public List<DonorPost> getPost(){
        return postDonorRepository.findAll();
    }

    @GetMapping("/auth/getDonorPostById/{id}")
    public DonorPost getPostById(@PathVariable("id") Long id){
        return postDonorRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("DonorPost", "id", id));
    }

    @PostMapping("/donorPost/update")
    public DonorPost updateDonorPost(@RequestBody DonorPost donorPost){
        return postDonorRepository.save(donorPost);
    }

    @GetMapping("/donor/getMyPosts")
    public List<DonorPost> getMyPosts(@AuthenticationPrincipal UserDetails userDetails){
        User user = userRepository.findByUsername(userDetails.getUsername()).orElseThrow(() -> new ResourceNotFoundException("User", "Username", userDetails.getUsername()));
        Donor donor = donorRepository.findByUser(user);
        return postDonorRepository.findByDonor(donor);
    }

    @GetMapping("/donor/allPosts")
    public List<DonorPost> allDonorPosts(){
        return postDonorRepository.findAcceptedPosts();
    }

}
