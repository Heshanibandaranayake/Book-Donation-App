package com.bookdrivebackend.controller;

import com.bookdrivebackend.entities.User;
import com.bookdrivebackend.entities.UserRepository;
import com.bookdrivebackend.exception.ResourceNotFoundException;
import com.bookdrivebackend.model.Club;
import com.bookdrivebackend.model.DonorPost;
import com.bookdrivebackend.model.SocietyPost;
import com.bookdrivebackend.repository.ClubRepository;
import com.bookdrivebackend.repository.PostClubRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

@RestController
public class PostClubController {
    @Autowired
    PostClubRepository postClubRepository;

    @Autowired
    ClubRepository clubRepository;

    @Autowired
    UserRepository userRepository;

    @PostMapping("/auth/createClubPost")
    public SocietyPost createNewClubPost(@RequestBody @Valid SocietyPost societyPost, @AuthenticationPrincipal UserDetails userDetails){
        User user = userRepository.findByUsername(userDetails.getUsername()).orElseThrow(() -> new ResourceNotFoundException("User", "Username", userDetails.getUsername()));
        Club club = clubRepository.findByUser(user);
        societyPost.setClub(club);
        return postClubRepository.save(societyPost);
    }

}
