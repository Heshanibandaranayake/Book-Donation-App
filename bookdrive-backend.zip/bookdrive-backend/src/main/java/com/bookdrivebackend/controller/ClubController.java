package com.bookdrivebackend.controller;

import com.bookdrivebackend.entities.User;
import com.bookdrivebackend.entities.UserRepository;
import com.bookdrivebackend.exception.ResourceNotFoundException;
import com.bookdrivebackend.model.Club;
import com.bookdrivebackend.repository.ClubRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
public class ClubController {
    @Autowired
    ClubRepository clubRepository;

    @Autowired
    UserRepository userRepository;

//    @PostMapping("/newClub")
//    public Club createNewClub(@RequestBody @Valid Club club){
//        return clubRepository.save(club);
//    }

    @GetMapping("/club/getMe")
    public Club getMe(@AuthenticationPrincipal UserDetails userDetails){
        User user = userRepository.findByUsername(userDetails.getUsername()).orElseThrow(() -> new ResourceNotFoundException("User", "username", userDetails.getUsername()));
        return clubRepository.findByUser(user);
    }
}
