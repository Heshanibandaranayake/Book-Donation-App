package com.bookdrivebackend.controller;

import com.bookdrivebackend.model.Quria;
import com.bookdrivebackend.repository.QuriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
public class QuriaController {
    @Autowired
    QuriaRepository quriaRepository;

//    @PostMapping("/newDriver")
//    @CrossOrigin(origins = "http://localhost:8100")
//    public Quria createNewDriver(@RequestBody @Valid Quria quria){
//        return quriaRepository.save(quria);
//    }
}
