package com.bookdrivebackend.controller;

import com.bookdrivebackend.dto.UserDto;
import com.bookdrivebackend.entities.User;
import com.bookdrivebackend.entities.UserRepository;
import com.bookdrivebackend.enums.UserTypes;
import com.bookdrivebackend.exception.ResourceNotFoundException;
import com.bookdrivebackend.model.Club;
import com.bookdrivebackend.model.Donor;
import com.bookdrivebackend.model.Quria;
import com.bookdrivebackend.repository.ClubRepository;
import com.bookdrivebackend.repository.DonorRepository;
import com.bookdrivebackend.repository.QuriaRepository;
import com.bookdrivebackend.security.AuthenticationRequest;
import com.bookdrivebackend.security.JwtTokenProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/auth")
public class AuthController {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    DonorRepository donorRepository;

    @Autowired
    ClubRepository clubRepository;

    @Autowired
    QuriaRepository quriaRepository;

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    JwtTokenProvider jwtTokenProvider;

    @Autowired
    PasswordEncoder passwordEncoder;

    @PostMapping("/signin")
    public ResponseEntity signin(@RequestBody AuthenticationRequest data) {
        try {
            String username = data.getUsername();
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, data.getPassword()));
            String token = jwtTokenProvider.createToken(username, userRepository.findByUsername(username).orElseThrow(() -> new ResourceNotFoundException("User", "Username", username)).getRoles());

            User user = userRepository.findByUsername(username).orElseThrow(() -> new ResourceNotFoundException("User", "Username", username));
            Map<Object, Object> model = new HashMap<>();
            model.put("username", username);
            model.put("token", token);
            model.put("userType",user.getUserType());
            return ResponseEntity.ok(model);
        }catch (AuthenticationException e){
            throw new BadCredentialsException("Invalid username/password supplied");
        }
    }

    @PostMapping("/signup")
    public ResponseEntity signup(@RequestBody UserDto userDto){
        User user = new User(userDto.getUsername(), passwordEncoder.encode(userDto.getPassword()), userDto.getName());
        user.setUserType(userDto.getUserType());
        user.setRoles(Arrays.asList( "ROLE_USER"));
        user = userRepository.save(user);
        if (user.getUserType() == UserTypes.DONOR){
            donorRepository.save(new Donor(userDto.getName(), userDto.getUsername(), userDto.getContact(), user));
        }else if (user.getUserType() == UserTypes.CLUB){
            clubRepository.save(new Club(userDto.getName(), userDto.getUsername(), userDto.getContact(), user));
        }else if (user.getUserType() == UserTypes.DRIVER){
            quriaRepository.save(new Quria(userDto.getName(), userDto.getUsername(), userDto.getVehicleNumber(), userDto.getContact(), user));
        }
        return ResponseEntity.ok(userDto);
    }

}
