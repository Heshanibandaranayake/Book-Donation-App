package com.bookdrivebackend.controller;

import com.bookdrivebackend.model.Donor;
import com.bookdrivebackend.repository.DonorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
public class DonorController {
    @Autowired
    DonorRepository donorRepository;

//    @PostMapping("/newDonor")
//    public Donor createNewDonor(@RequestBody @Valid Donor donor){
//        return donorRepository.save(donor);
//    }

}
