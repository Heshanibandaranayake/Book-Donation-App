package com.bookdrivebackend.service.impl;

import com.bookdrivebackend.exception.ResourceNotFoundException;
import com.bookdrivebackend.model.Quria;
import com.bookdrivebackend.repository.QuriaRepository;
import com.bookdrivebackend.service.QuriaService;
import org.springframework.beans.factory.annotation.Autowired;

public class QuriaServiceImpl implements QuriaService {
    @Autowired
    QuriaRepository quriaRepository;

    @Override
    public Quria getDriverById(Long Id) {
        return quriaRepository.findById(Id).orElseThrow(()-> new ResourceNotFoundException("UserQuriaEntity","Id",Id));
    }
}
