package com.bookdrivebackend.service;

import com.bookdrivebackend.model.Donor;

public interface DonorService {
    Donor getDonorById(Long Id);
}
