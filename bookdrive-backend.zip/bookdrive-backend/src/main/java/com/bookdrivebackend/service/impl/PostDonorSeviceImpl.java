package com.bookdrivebackend.service.impl;

import com.bookdrivebackend.exception.ResourceNotFoundException;
import com.bookdrivebackend.model.DonorPost;
import com.bookdrivebackend.repository.PostDonorRepository;
import com.bookdrivebackend.service.PostDonorService;
import org.springframework.beans.factory.annotation.Autowired;

public class PostDonorSeviceImpl implements PostDonorService {
    @Autowired
    PostDonorRepository postDonorRepository;

    @Override
    public DonorPost getPostById(Long id) {
        return postDonorRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("PostDonorEntity","Id",id));
    }
}
