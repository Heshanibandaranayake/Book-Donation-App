package com.bookdrivebackend.service.impl;

import com.bookdrivebackend.exception.ResourceNotFoundException;
import com.bookdrivebackend.model.SocietyPost;
import com.bookdrivebackend.repository.PostClubRepository;
import com.bookdrivebackend.service.PostClubService;
import org.springframework.beans.factory.annotation.Autowired;

public class PostClubServiceImpl implements PostClubService {
    @Autowired
    PostClubRepository postClubRepository;

    @Override
    public SocietyPost getClubById(Long id) {
        return postClubRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("PostClubEntity","Id",id));
    }
}
