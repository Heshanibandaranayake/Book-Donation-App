package com.bookdrivebackend.service;

import com.bookdrivebackend.model.DonorPost;

public interface PostDonorService {
    DonorPost getPostById(Long id);
}
