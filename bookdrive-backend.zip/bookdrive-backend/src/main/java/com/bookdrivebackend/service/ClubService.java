package com.bookdrivebackend.service;

import com.bookdrivebackend.model.Club;

public interface ClubService {
    Club getClubById(Long id);

}
