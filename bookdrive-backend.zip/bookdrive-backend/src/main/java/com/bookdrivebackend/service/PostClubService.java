package com.bookdrivebackend.service;

import com.bookdrivebackend.model.SocietyPost;

public interface PostClubService {
    SocietyPost getClubById(Long id);
}
