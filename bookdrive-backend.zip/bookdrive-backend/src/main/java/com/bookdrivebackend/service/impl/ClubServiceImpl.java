package com.bookdrivebackend.service.impl;

import com.bookdrivebackend.exception.ResourceNotFoundException;
import com.bookdrivebackend.model.Club;
import com.bookdrivebackend.repository.ClubRepository;
import com.bookdrivebackend.service.ClubService;
import org.springframework.beans.factory.annotation.Autowired;

public class ClubServiceImpl implements ClubService {
    @Autowired
    ClubRepository clubRepository;

    @Override
    public Club getClubById(Long id) {
        return clubRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("UserClubEntity","Id",id));
    }
}
