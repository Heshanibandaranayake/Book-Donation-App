package com.bookdrivebackend.service;

import com.bookdrivebackend.model.Quria;

public interface QuriaService {
    Quria getDriverById(Long Id);
}
