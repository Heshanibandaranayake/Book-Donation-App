package com.bookdrivebackend.service.impl;

import com.bookdrivebackend.exception.ResourceNotFoundException;
import com.bookdrivebackend.model.Donor;
import com.bookdrivebackend.repository.DonorRepository;
import com.bookdrivebackend.service.DonorService;
import org.springframework.beans.factory.annotation.Autowired;

public class DonorServiceImpl implements DonorService {
    @Autowired
    DonorRepository donorRepository;

    @Override
    public Donor getDonorById(Long Id) {
        return donorRepository.findById(Id).orElseThrow(()-> new ResourceNotFoundException("UserDonorEntity","Id",Id));
    }
}
